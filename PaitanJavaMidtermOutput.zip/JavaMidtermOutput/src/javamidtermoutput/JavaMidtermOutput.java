/** Jennie Rose Paitan BSIS 2A
 * Create an array list which has two fields for each person. The name and age
 */
package javamidtermoutput;

import javax.swing.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

public class JavaMidtermOutput
    {
    public static void main(String[] args)
     {
        ListofPersonEntered lpe = new ListofPersonEntered();
        FMngt fm = new FMngt("data.csv", lpe);
        WinMngt wm = new WinMngt(lpe, fm);

        wm.showMenu();
    }
}

class PersonEntered
    {
    String name;
    int age;
   
    public PersonEntered(String name, int age)
    {
        this.name = name;
        this.age = age;
    }
}

class ListofPersonEntered
    {
    public ArrayList<PersonEntered> personenteredArrayList = new ArrayList<>();
   
    public void addEntry(String name, int age)     //Add Entry
           
    {
        PersonEntered newPersonEntered = new PersonEntered(name, age);
        personenteredArrayList.add(newPersonEntered);
    }
   
    public void deleteEntry(int index)       //Delete Entry
    {
        personenteredArrayList.remove(index);
    }
   
    public void updateEntry(String name, int age, int index)      //Update An Entry
    {
        personenteredArrayList.get(index).name = name;
        personenteredArrayList.get(index).age = age;
    }
}

final class FMngt
    {
    String filePath = "data.txt";
    ListofPersonEntered lp;
   
    public FMngt (String filePath, ListofPersonEntered lp)
    {
        this.lp = lp;
        this.filePath = filePath;
        CreateFile();   
        ReadFile();
    }
   
    public void CreateFile()
    {
        try
        {
            File myFile = new File(filePath);
            if (myFile.createNewFile())
            {
                System.out.println("File created: " + myFile.getName());
            } else
            {
                System.out.println("File already exists.");
            }
        } catch (IOException e)
        {
            System.out.println("An error occured.");
        }
    }

    public void ReadFile ()
        {
        try
        {
            File myFile = new File(filePath);
            try (Scanner myReader = new Scanner(myFile) //Converts Text File into PersonEnteredArrayList Format
            ) {
                while (myReader.hasNextLine())
                {
                    String line = myReader.nextLine();
                    String[] lineArray = line.split(",");
                    PersonEntered newPersonEntered = new PersonEntered(lineArray[0], Integer.parseInt(lineArray[1]));
                    lp.personenteredArrayList.add(newPersonEntered);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("An Error Occurred.");
        }
    }

    public void WriteToFile()
    {
        try
        {
            try (FileWriter myWriter = new FileWriter(filePath)) {
                for (PersonEntered p : lp.personenteredArrayList)
                {
                    myWriter.write(p.name+","+p.age+"\n");
                }
            }
            System.out.println("         * * Success!! * *" + "\n" + "You Have Put Some Changes to the File.\n" + "       * * * * * * * * * * *" + "\n");
        } catch (IOException e)
        {
            System.out.println("An Error Occurred.");
        }
    }
}

class WinMngt 
    {
    ListofPersonEntered lp;
    FMngt fm;
    public WinMngt(ListofPersonEntered lp, FMngt fm)
    {
        this.lp = lp;
        this.fm = fm;
    }

    public void showMenu()
                {
        String[] options = {"1 Add Entry", "2 Delete Entry", "3 View All Entries", "4 Update An Entry", "0 Exit"};
        int choice = JOptionPane.showOptionDialog(null,
                "                                                  ^^^ JAVA MIDTERM OUTPUT ^^^" +
                "\n\t\t" +
                "\t\t\t                                                      JENNIE ROSE PAITAN BSIS 2A" +
                "     \n\n                                                           Select an Option: ",
                "Java Midterm Output", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice)
            {
            case 0:
                showAdd();
               
                break;
            case 1:
                showDelete();
               
                break;
            case 2:
                showEntries();
               
                break;
            case 3:
                showUpdate();
               
                break;
            case 4:
                showExit();
               
                break;
            }
    }

    public void showAdd()
    {
        JTextField name = new JTextField();
        JTextField age = new JTextField();
        Object[] addField =
        {
                "              ** ADD ENTRY **" +
                "                      \n\n",
                "                    Enter Name: ",name,
                "                      Enter Age: ",
                    age };
       
        int confirm = JOptionPane.showConfirmDialog(null, addField, "Add Entry", JOptionPane.OK_CANCEL_OPTION);
        if (confirm == JOptionPane.OK_OPTION) 
            {
            try
            {
                int ageInt = Integer.parseInt(age.getText());
                lp.addEntry(name.getText(), ageInt);
                fm.WriteToFile();
                String message = "You have successfully added " + name.getText() + " in the list. \n\t\t\t\t Thank you!" ;
                showSuccess(message);
            }
            catch (NumberFormatException e)
            {
                showAdd();
            }
        }
        else
        {
            showMenu();
        }
    }

    public void showDelete()
        {
        JTextField deleteIndex = new JTextField();
        String entriesField = "";
        for (int i = 0; i < lp.personenteredArrayList.size(); i++)
        {
            entriesField += i+1 + ". " + lp.personenteredArrayList.get(i).name + " is " + lp.personenteredArrayList.get(i).age + " years old." + "\n";
        }
        entriesField += "\n";

        Object[] deleteField =
        {
                entriesField,
                "             ** DELETE ENTRY **" +
                "                      \n\n",
                "To delete an entry, select a number from the list.",
                deleteIndex
        };
       
        int confirm = JOptionPane.showConfirmDialog(null, deleteField, "Delete Entry", JOptionPane.OK_CANCEL_OPTION);
        if (confirm == JOptionPane.OK_OPTION) {
            try {
                int deleteIndexInt = Integer.parseInt(deleteIndex.getText()) - 1;
                if (deleteIndexInt >= lp.personenteredArrayList.size()) {
                    throw new IndexOutOfBoundsException("Index " + deleteIndexInt + " is out of bounds!");
                }
                String message = "You have successfully deleted " + lp.personenteredArrayList.get(deleteIndexInt).name + " on the list. ";
                lp.deleteEntry(deleteIndexInt);
                fm.WriteToFile();
               
                showSuccess(message);
            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                showDelete();
            }
        } else
        {
            showMenu();
        }
    }

    public void showEntries()
        {
        String[] entriesButton = {"Back To Menu"};
        String entriesField = "";

        for (int i = 0; i < lp.personenteredArrayList.size(); i++)
        {
            entriesField += i+1 + ". " + lp.personenteredArrayList.get(i).name + " is " + lp.personenteredArrayList.get(i).age + " years old.\n";
        }

        entriesField += "\n";

        JOptionPane.showOptionDialog(null, entriesField, "View All Entries", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, entriesButton, entriesButton[0]);
        showMenu();
    }

    public void showUpdate()
        {
        JTextField updateIndex = new JTextField();
        String entriesField = "";
        for (int i = 0; i < lp.personenteredArrayList.size(); i++)
        {
            entriesField += i+1 + ". " + lp.personenteredArrayList.get(i).name + " is " + lp.personenteredArrayList.get(i).age + " years old." + "\n";
        }
        entriesField += "\n";

        Object[] updateField =
                {
                entriesField,
                "              ** UPDATE AN ENTRY ** " +
                "                      \n\n",
                "To update an entry, select a number from the list.",
                updateIndex
        };
        int confirm = JOptionPane.showConfirmDialog(null, updateField, "Update An Entry", JOptionPane.OK_CANCEL_OPTION);
        if (confirm == JOptionPane.OK_OPTION)
                {
            try
                {
                int updateIndexInt = Integer.parseInt(updateIndex.getText()) - 1;
                if (updateIndexInt >= lp.personenteredArrayList.size())
                {
                    throw new IndexOutOfBoundsException("Index " + updateIndexInt + " is out of bounds!");
                }
                showUpdatePrompt(updateIndexInt);
            } catch (NumberFormatException | IndexOutOfBoundsException e)
            {
                showUpdate();
            }
        }
       
        else
           {
            showMenu();
        }
    }
    public void showUpdatePrompt(int updateIndexInt)
        {
        JTextField newName = new JTextField();
        JTextField newAge = new JTextField();
        Object[] updateField =
        {
                "Current Name: " + lp.personenteredArrayList.get(updateIndexInt).name,
                "Current Age: " + lp.personenteredArrayList.get(updateIndexInt).age + "\n\n",
                "                     Enter New Name: ", newName,
                "                     Enter New Age: ", newAge,
                "\n"
        };
        int confirm = JOptionPane.showConfirmDialog(null, updateField, "Updating... ", JOptionPane.OK_CANCEL_OPTION);
        if (confirm == JOptionPane.OK_OPTION)
            {
            try
            {
                int newAgeInt = Integer.parseInt(newAge.getText());
                String message = lp.personenteredArrayList.get(updateIndexInt).name +
                 " is Successfully Updated to\n" + newName.getText() + " with the Age of " + newAge.getText() + ". " ;
                lp.updateEntry(newName.getText(), newAgeInt, updateIndexInt);
                fm.WriteToFile();
                showSuccess(message);
            }
            catch (NumberFormatException e)
            {
                showUpdatePrompt(updateIndexInt);
            }
        }
        else
        {
            showUpdate();
        }
    }
   
public void showSuccess(String message)
    {
        String[] successField = {"Back To Menu"};
        JOptionPane.showOptionDialog(null, message, "Success!", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, successField, successField[0]);
        showMenu();
    }

    private void showExit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}